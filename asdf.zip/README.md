#Personal Website


On this website I will include a blog, information about me, a link to my GitHub, a link to my Twitter, a link to chat, my contact information, and perhaps links to live versions of some personal creations. I plan on starting an IRC server and linking to a webchat on my website.


This site uses a bird animation enabled by three.js. I did not design the birds - creds to Mr Doob for that. I did, however, customize the visualization.


This website is responsive and should be to-scale on any device dimentions.
